/**********************************************************************************
*  File:        ICA9.c
*  Project:     ICA9
*  Author:      Gumesh Teklay
*  Student #:   200444630
*  Version:     1.0
*  Date:        4/5/2020
*  Course:      CMPE1700
*  Instructor:  Oveeyen Moonian
*  Description: Create a struct type that can store Student's name, ID number and Marks
* ********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "student.h"

struct Node
{
	Student data;
	struct Node* next;
};

// Function prototypes
// struct Students initializeStudents();
void initializeStudents();
int main()
{
	initializeStudents();
	// Student students = initializeStudents();

	int optionSelected, data;
	// An infinite loop until option 5. Exit is selected
	for (;;)
	{
		// Display the menu of options
		printf("1. Display list in order of id's.\n");
		printf("2. Display list in descending order of Marks.\n");
		printf("3. Display the names, marks and rank of a person given the ID (ID should be input).\n");
		printf("4. Display the names and marks of all person above a threshold marks value (the threshold value should be input).\n");
		printf("5. Exit.\n");

		// Read and store the option the user selected
		scanf_s("%d", &optionSelected);

		// Check to see which of the 5 options was selected and call the appropriate function

		// Option 1. Order students according to ids
		if (optionSelected == 1)
		{
			return 0;
		}
		// Option 2. Order students according to marks from largest to smallest
		else if (optionSelected == 2)
		{
			return 0;
		}
		// Option 3. Display student given when given the student id
		else if (optionSelected == 3)
		{
			return 0;
		}
		// Option 4. Display all students with marks above given value
		else if (optionSelected == 4)
		{
			return 0;
		}
		// Option 5. Exit: Leave the program
		else if (optionSelected == 5)
		{
			break;
		}
	}

	return 0;
}

void initializeStudents()
{
	// 1) Create an array of strings (2-D array of char) to store 10 names
	char* tenStudentNames[10] = { "Gumesh", "Bob", "Joe", "Jane", "Michelle", "Sarah", "Ezra", "Ada", "Mimi", "Annie" };

	/* 2) Create an array of 10 int values, representing the ID of the persons in the
	first array (The ID's should not be in ascending order) */
	int tenStudentIds[10] = { 123, 901, 789, 678, 345, 212, 456, 234, 567, 890 };

	/* 3) Creates an array of size 10 of Marks, representing the Marks of the
	persons in the first array (The marks should not be in ascending order) */
	struct Marks tenStudentMarks[10];
	int marks[10] = { 98, 33, 77, 10, 80, 45, 56, 92, 64, 28 };
	for (int currStudent = 0; currStudent < 10; currStudent++)
	{
		tenStudentMarks[currStudent].mark = marks[currStudent];
	};

	/* 4) Can be broken down to three steps:
		4.1) Build each student struct, where each struct contains the name, ID and
	marks of a person.
		4.2) Build a linked list filled with the student structs
		4.2) The list should be ordered in increasing order of ID
	*/

	// 4.1) Build each student struct
	struct Student tenStudents[10];
	for (int currStudent = 0; currStudent < 10; currStudent++)
	{
		tenStudents[currStudent].firstName = tenStudentNames[currStudent];
		// for testing: printf("First name: %s\n", tenStudents[currStudent].firstName);
		tenStudents[currStudent].studentId.id = tenStudentIds[currStudent];
		// for testing: printf("Student ID: %d\n", tenStudents[currStudent].studentId.id);
		tenStudents[currStudent].studentMark.mark = tenStudentMarks[currStudent].mark;
		// for testing: printf("Mark: %d\n", tenStudentMarks[currStudent].mark);
	};

	// 4.2) Build the linked list
	for (int currStudent = 0; currStudent < 10; currStudent++)
	{
		if (currStudent != 9)
		{
			tenStudents[currStudent].nextStudent = &tenStudents[currStudent + 1];
		}
		else
		{
			tenStudents[currStudent].nextStudent = NULL;
		}
	};
	//return students;
	return;
}