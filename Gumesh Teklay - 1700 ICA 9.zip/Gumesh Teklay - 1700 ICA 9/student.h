#pragma once
typedef struct Marks
{
	int mark;
	int orderedKey;
} Marks;

typedef struct ID
{
	int id;
	int orderedKey;
} ID;

// struct Node
// {
//     Student data;
//     struct Node *next;
// };
typedef struct Student
{
	char* firstName;
	struct ID studentId;
	struct Marks studentMark;
	struct Student* nextStudent;
} Student;
